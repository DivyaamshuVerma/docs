function data(){
    var a = document.getElementById("n1").value;
    var b = document.getElementById("n2").value;
    var c = document.getElementById("n3").value;
    var d = document.getElementById("n4").value;
    
    if(a=="" || b=="" || c=="" || d==""){
        alert("All Fields are mendatory.");
        return false;
    }else if(b.length<10||b.length>10){
        alert("Number should be of 10 Digits in Contact field.")
        return false;
    }else if(isNaN(b)){
        alert("Only Numbers are allowed in Contact field.")
        return false;
    }else if(c!=d){
        alert("Please enter same data in both Password and Confirm Password fields.")
        return false;
    }
    else{
        true;
    }
    resetForm();
}

function resetForm() {
    document.getElementById("n1").value = "";
    document.getElementById("n2").value = "";
    document.getElementById("n3").value = "";
    document.getElementById("n4").value = "";
    selectedRow = null;
}
