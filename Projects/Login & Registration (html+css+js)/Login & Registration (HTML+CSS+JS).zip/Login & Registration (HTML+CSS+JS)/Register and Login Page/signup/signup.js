function data(){
    var a = document.getElementById("firstname-input").value;
    var b = document.getElementById("email-input").value;
    var c = document.getElementById("password-input").value;
    var d = document.getElementById("repeat-password-input").value;
    
    if(a=="" || b=="" || c=="" || d==""){
        alert("All Fields are mendatory.");
        return false;
    }else if(c!=d){
        alert("Please enter same data in both Password and Confirm Password fields.")
        return false;
    }
    else{
        true;
    }
    resetForm();
}

function resetForm() {
    document.getElementById("firstname-input").value = "";
    document.getElementById("email-input").value = "";
    document.getElementById("password-input").value = "";
    document.getElementById("repeat-password-input").value = "";
    selectedRow = null;
}
